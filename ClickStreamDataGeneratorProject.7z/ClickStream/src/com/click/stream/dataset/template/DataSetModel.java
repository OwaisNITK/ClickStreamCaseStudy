package com.click.stream.dataset.template;

import java.util.List;

// TODO: Auto-generated Javadoc
/** The Class DataSetModel. */
public class DataSetModel {

    /** The data list. */
    List<String> dataList;

    /** Gets the data list.
     *
     * @return the data list */
    public List<String> getDataList() {
        return dataList;
    }

    /** Sets the data list.
     *
     * @param dataList
     *            the new data list */
    public void setDataList(List<String> dataList) {
        this.dataList = dataList;
    }
}